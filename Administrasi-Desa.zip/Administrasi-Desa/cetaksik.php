<style type="text/css">
  @font-face {
    font-family: myFirstFont;
    src: url(fonts/ufonts.com_square721-bt-roman.ttf);
  }

  p, u, td{
    font-family: myFirstFont;
  }
</style>
<title>Print Data Surat Izin Keramaian</title>
<body onLoad="window.print()">

<table border=0 width=100%>
<tr>
    <td align="center" rowspan='3' width='88px'><img src='logo.jpeg' width='85px'></td>
</tr> 
<tr>
<tr>
    <td align="center"><h3 style='margin-bottom:-5px' align=center>PEMERINTAH KABUPATEN SERANG<br>
         KECAMATAN CIKANDE<br> DESA SITUTERATE</h3></td>
    <td align="center" rowspan='3' width='88px'>&nbsp;</td>
</tr> 
<tr>
    <td align="center"><p>Jl. Pemda Cikande - Bandung Kecamatan Cikande Kabupaten Serang Tlp.(081) 6575624 Kode pos 42186</p></td>
</tr>  
</table>
<hr style='border:1px solid #000'>

<table width=100%>
<tr>
    <td align="center"><h3 style='margin-bottom:-5px' align=center><u>SURAT IZIN KERAMAIAN</u> </h3></td>
</tr>
<?php
session_start();
include "koneksi.php"; 
 

                        $sql = "select * from sik INNER JOIN data ON sik.id_data=data.id_data where id_sik='$_GET[id_sik]'";
                        $query = $conn->query($sql);
                        while ($admin = $query->fetch_array()) { ?> 
<tr>
    <td align="center"><p>Nomor : 00<?php echo "$admin[id_sik]"; ?>-DS-IX-2019</p></td>
</tr> 
</table>

<table width='100%'>
<tr>
  <td>Yang bertanda tangan di bawah ini, Kepala Desa Situterate Kecamatan Cikande Kabupaten Serang, dengan ini
menerangkan sesungguhnya bahwa :  </td>
</tr>

</table>
<br>


<table width='100%' >
<tr>
<td></td>
<td width="40%">Nama Lengkap</td>
<td width="95%">: <?php echo "$admin[nama]";?></td>
</tr>
<tr>
<td></td>
<td>NIK</td>
<td>: <?php echo "$admin[nik]";?></td>
</tr>
<tr>
<td></td>
<td>Kewarganegaraan</td>
<td>: <?php echo "$admin[kewarganegaraan]";?></td>
</tr>
<tr>
<td></td>
<td>Alamat</td>
<td>: <?php echo "$admin[alamat]";?></td>
</tr>
</table>
<table width='100%'>
<tr>
  <td>Benar bahwa yang bersangkutan diatas adalah Warga Desa Situterate yang bermaksud untuk memohon Surat Izin Keramaian dalam rangka : </td>
</tr>
  </table>
<table width='100%' >
<tr>
<td></td>
<td width="40%">Acara</td>
<td width="95%">: <?php echo "$admin[acara]";?></td>
</tr>
<tr>
<td></td>
<td>Tanggal Keramaian</td>
<td>: <?php echo ($admin['tgl']);?></td>
</tr>
<tr>
<td></td>
<td>Tempat Acara</td>
<td>: <?php echo "$admin[tempp]";?></td>
</tr>
</table>
<?php
                                        }
            
                                ?>
<p>Demikian Surat pengantar permohonan izin keramian ini kami buat dengan sebenarnya untuk dapat dipergunakan sebagaimana seperlunya.</p>
<table width=100%>
  <tr>
    <td width="30%">
	
	
	<center>
        <br><br><br> 
		CAMAT SITUTERATE<br><br><br><br><br><br>

           <br>
         
    
        </center>
    </td>
    </td>

    <td width="30%">

    </td>

    <td >
       
        <table align = "center">
            
            <tr>
              <td>Situterate,</td>
              <td> <?php echo date("d M Y"); ?></td></tr>
        </table><br>
        <center>
          KEPALA DESA SITUTERATE<br><br><br><br><br><br>

          RIKI AMALUDIN <br>
         
    
        </center>
    </td>
  </tr>
</table> 
</body>