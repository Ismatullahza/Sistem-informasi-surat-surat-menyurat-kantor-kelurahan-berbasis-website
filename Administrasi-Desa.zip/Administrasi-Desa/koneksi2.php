<?php

$koneksi = mysqli_connect("localhost","root","","layanan desa") 
or die(mysqli_connect_error());

?>