<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- bootstrap 5.2 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <!-- fontawesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- css buatan sendiri -->
    <link rel="stylesheet" href="css/style_dashboard.css">
    <title>SIK Edit | SI Administrasi Desa</title>
	    <link rel="icon" href="logo.jpeg">
</head>

<body>

    <nav class="navbar navbar-dark" style="background-color: #22333E;">
        <div class="container-fluid">
            <a class="navbar-brand">Sistem Layanan Administrasi Desa</a>
            <form class="d-flex" role="search">
                <a href="logout.php" class="btn btn-outline-danger btn-sm" role="button">LOG OUT</a>
            </form>
        </div>
    </nav>

    <div class="d-flex bg-secondary text-white" id="wrapper">
        <!-- Sidebar -->
        <div class="" id="sidebar-wrapper" style="background-color: #5a636b;">
            <div class="list-group list-group-flush my-3">
            <a href="admin.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i class="fas fa-home me-2"></i>Dashboard</a>
                <a href="adminprofil.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i class="fas fa-user me-2"></i>Profil</a>
                <a href="adminjadwal.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i class="fas fa-clock me-2"></i>Jadwal</a>
                <a href="admincetakskck.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i class="fas fa-envelope me-2"></i>Cetak SKCK</a>
                <a href="admincetaksktm.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i class="fas fa-envelope me-2"></i>Cetak SKTM Sekolah</a>
                <a href="admincetaksik.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold active"><i class="fas fa-envelope me-2"></i>Cetak Surat Izin Keramaian</a>
                <a href="admincetakusaha.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i class="fas fa-envelope me-2"></i>Cetak Surat Keterangan Usaha</a>
                <a href="admincetakskd.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i class="fas fa-envelope me-2"></i>Cetak Surat Keterangan Domisili</a>
                
            </div>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        
        <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg navbar-light bg-transparent py-4 px-4">
                <div class="d-flex align-items-center">
                    <i class="fas fa-align-left primary-text fs-4 me-3" id="menu-toggle"></i>
                    <h2 class="fs-2 m-0">Edit Data</h2>
                </div>
            </nav>
            <div class="container-sm">
                <hr class="border-light border-2 opacity-75">
                <h2>Update Data Produk</h2>

<form method="post" action="data-simpan.php">
<table border="1" style="border-collapse:collapse">
<tr bgcolor="#eee">
    <th width="50">Acara</th>
    <th width="200">Tanggal Keramaian</th>
    <th width="100">Tempat Keramaian</th>
</tr>

<?php
include "koneksi.php";

// Cek apakah form dikirim dan id ada
if (isset($_POST['id']) && is_array($_POST['id']) && count($_POST['id']) > 0) {
    $idArray = $_POST['id'];
    $jum = count($idArray);
} else {
    // Tidak ada id yang dipilih → hentikan proses dan beri pesan
    echo "<p>Tidak ada data yang dipilih untuk diedit.</p>";
    echo "<p><a href='admincetaksik.php'>Kembali ke halaman sebelumnya</a></p>";
    exit;
}
?>

<form method="post" action="data-simpan.php">
    <table border="1" style="border-collapse:collapse">
        <tr bgcolor="#eee">
            <th width="50">Acara</th>
            <th width="200">Tanggal Keramaian</th>
            <th width="100">Tempat Keramaian</th>
        </tr>
        <?php
        for ($i = 0; $i < $jum; $i++) {
            // Escape input id untuk keamanan
            $id = mysqli_real_escape_string($conn, $idArray[$i]);

            $ambildata = mysqli_query(
                $conn,
                "SELECT * FROM sik WHERE id_sik='$id'"
            ) or die(mysqli_error($conn));

            while ($tampil = mysqli_fetch_assoc($ambildata)) {
                echo "<tr>
                        <td><input type='text' name='acara[]' value='".htmlspecialchars($tampil['acara'], ENT_QUOTES)."' size='8'></td>
                        <td><input type='text' name='tgll[]' value='".htmlspecialchars($tampil['tgll'], ENT_QUOTES)."' size='25'></td>
                        <td><input type='text' name='tempp[]' value='".htmlspecialchars($tampil['tempp'], ENT_QUOTES)."' size='10'></td>
                        <input type='hidden' name='id[]' value='".htmlspecialchars($tampil['id_sik'], ENT_QUOTES)."'>
                      </tr>";
            }
        }
        ?>
    </table>

    <input type="hidden" name="jum" value="<?php echo $jum; ?>">
    <input type="submit" name="proses" value="Simpan" style="margin-top:5px">
    <input type="button" value="Kembali" onclick="location.href='admincetaksik.php';">
</form>
