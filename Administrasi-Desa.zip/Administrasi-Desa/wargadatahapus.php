<?php
session_start();
include "koneksi.php";

// 🧹 Letakkan semua logika delete di sini, sebelum output HTML
if (isset($_POST['hapus'])) {
    $id = (int)$_POST['id_data'];

    // Daftar tabel child yang punya FK ke "data"
    $childTables = ['sik', 'skd', 'skck', 'sktm', 'usaha'];

    foreach ($childTables as $table) {
        $stmt = $conn->prepare("DELETE FROM $table WHERE id_data = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }

    $stmtMain = $conn->prepare("DELETE FROM data WHERE id_data = ?");
    $stmtMain->bind_param("i", $id);

    if ($stmtMain->execute()) {
        $_SESSION['msg'] = "Data berhasil dihapus!";
    } else {
        $_SESSION['msg'] = "Data gagal dihapus!";
    }

    header("Location: wargadata.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Hapus Data</title></head>
<body>
    <?php
    // Jika ada pesan dari proses delete
    if (!empty($_SESSION['msg'])) {
        echo "<script>alert('{$_SESSION['msg']}');</script>";
        unset($_SESSION['msg']);
    }
    ?>
    <!-- Konten HTML lainnya (form / tabel dsb) -->
</body>
</html>